/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bhaskara;
import java.util.Scanner;
/**
 *
 * @author rafael.psilva70
 */
public class Bhaskara {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o Valor de A");
        int a = sc.nextInt();
        
        System.out.println("Digite o Valor de B");
        int b = sc.nextInt();
        
        System.out.println("Digite o Valor de C");
        int c = sc.nextInt();
        
        double delta = (b*b)-4*a*c;
        
        System.out.println(delta + "\n");
        
        double raiz = Math.sqrt(delta);
        
        System.out.println(raiz + "\n");
        
        double x1 = (-b+raiz)/(2*a);
        double x2 = (-b-raiz)/(2*a);
        
        System.out.println(x1 + "\n" + x2);
    }
    
}
