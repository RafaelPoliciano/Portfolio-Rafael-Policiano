/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

import java.util.Scanner;

/**
 *
 * @author rafael.psilva70
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Welcome to Calculator!");
        Scanner sc = new Scanner(System.in);
        System.out.println("Insert a number: ");
        int num = sc.nextInt();
        System.out.println("Insert another number: ");
        int nom = sc.nextInt();
        
        System.out.println("Choose an operation: ");
        System.out.println("1 - Addition");
        System.out.println("2 - Subtraction");
        System.out.println("3 - Multiplication");
        System.out.println("4 - Division");
        
        System.out.println("Option: ");
        int opt = sc.nextInt();
        
        if (opt == 1) {
            int resultado = num + nom;
            System.out.println("Result: " + resultado);
        }
        else if (opt == 2){
            int resultado = num - nom;
            System.out.println("Result: " + resultado);
        }
        else if (opt == 3){
            int resultado = num * nom;
            System.out.println("Result: " + resultado);
        }
        else if (opt == 4){
            if (nom == 0) {
                System.out.println("Error! It is not possible to divide by zero!");
            }
            else {
            int resultado = num / nom;
            System.out.println("Result: " + resultado);
            }
    }
        
    }
}
