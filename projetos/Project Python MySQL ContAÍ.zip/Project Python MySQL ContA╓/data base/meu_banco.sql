-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28/12/2025 às 01:00
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `meu_banco`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `agenda`
--

CREATE TABLE `agenda` (
  `id` int(11) NOT NULL,
  `data_tarefa` date NOT NULL,
  `tarefa` text NOT NULL,
  `status` enum('Pendente','Concluída','Cancelada') DEFAULT 'Pendente',
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `agenda`
--

INSERT INTO `agenda` (`id`, `data_tarefa`, `tarefa`, `status`, `data_cadastro`, `data_atualizacao`) VALUES
(1, '2025-01-15', 'Pagar fornecedor ABC Serviços', 'Pendente', '2025-12-27 23:13:37', '2025-12-27 23:13:37'),
(2, '2025-01-20', 'Reunião com contador', 'Pendente', '2025-12-27 23:13:37', '2025-12-27 23:13:37'),
(3, '2025-01-25', 'Enviar relatório mensal', 'Pendente', '2025-12-27 23:13:37', '2025-12-27 23:13:37'),
(4, '2025-09-05', 'Sped Fiscal', 'Pendente', '2025-12-27 23:14:32', '2025-12-27 23:14:32'),
(5, '2025-09-20', 'PIS COFINS', 'Pendente', '2025-12-27 23:14:59', '2025-12-27 23:14:59'),
(6, '2025-01-15', 'Pagar fornecedor ABC Serviços', 'Pendente', '2025-12-27 23:58:19', '2025-12-27 23:58:19'),
(7, '2025-01-20', 'Reunião com contador', 'Pendente', '2025-12-27 23:58:19', '2025-12-27 23:58:19'),
(8, '2025-01-25', 'Enviar relatório mensal', 'Pendente', '2025-12-27 23:58:19', '2025-12-27 23:58:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `contas`
--

CREATE TABLE `contas` (
  `id` int(11) NOT NULL,
  `tipo` enum('Conta a Pagar','Conta a Receber') NOT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `razao_social` varchar(255) DEFAULT NULL,
  `valor` decimal(15,2) NOT NULL,
  `data_vencimento` date NOT NULL,
  `status` enum('Pendente','Paga','Recebida','Vencida') DEFAULT 'Pendente',
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `contas`
--

INSERT INTO `contas` (`id`, `tipo`, `cnpj`, `razao_social`, `valor`, `data_vencimento`, `status`, `data_cadastro`, `data_atualizacao`) VALUES
(1, 'Conta a Pagar', '12.345.678/0001-90', 'ABC Serviços Ltda', 1500.00, '2025-01-15', 'Pendente', '2025-12-27 23:13:37', '2025-12-27 23:13:37'),
(2, 'Conta a Receber', '98.765.432/0001-10', 'XYZ Consultoria S.A.', 3200.50, '2025-01-20', 'Pendente', '2025-12-27 23:13:37', '2025-12-27 23:13:37'),
(3, 'Conta a Pagar', '98.765.432/0001-10', 'XYZ Consultoria S.A.', 100000.00, '2025-12-27', 'Pendente', '2025-12-27 23:31:23', '2025-12-27 23:31:23'),
(4, 'Conta a Pagar', '12.345.678/0001-90', 'ABC Serviços Ltda', 1500.00, '2025-01-15', 'Pendente', '2025-12-27 23:58:19', '2025-12-27 23:58:19'),
(5, 'Conta a Receber', '98.765.432/0001-10', 'XYZ Consultoria S.A.', 3200.50, '2025-01-20', 'Pendente', '2025-12-27 23:58:19', '2025-12-27 23:58:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `contas_vencidas`
--

CREATE TABLE `contas_vencidas` (
  `id` int(11) NOT NULL,
  `tipo_conta` enum('Conta a Pagar','Conta a Receber') NOT NULL,
  `cnpj` varchar(18) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `valor` decimal(15,2) NOT NULL,
  `multa` decimal(15,2) NOT NULL DEFAULT 0.00,
  `data_vencimento` date NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Pendente','Paga','Recebida') DEFAULT 'Pendente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `contas_vencidas`
--

INSERT INTO `contas_vencidas` (`id`, `tipo_conta`, `cnpj`, `razao_social`, `valor`, `multa`, `data_vencimento`, `data_cadastro`, `data_atualizacao`, `status`) VALUES
(1, 'Conta a Receber', '98.765.432/0001-10', 'XYZ Consultoria S.A.', 100000.00, 5000.00, '2025-12-27', '2025-12-27 23:21:31', '2025-12-27 23:21:31', 'Pendente'),
(2, 'Conta a Pagar', '98.765.432/0001-10', 'XYZ Consultoria S.A.', 17000.00, 850.00, '2025-12-27', '2025-12-27 23:32:05', '2025-12-27 23:32:05', 'Pendente');

-- --------------------------------------------------------

--
-- Estrutura para tabela `escrituracao`
--

CREATE TABLE `escrituracao` (
  `id` int(11) NOT NULL,
  `tipo_nota` enum('Entrada','Saída','Serviços Tomados') NOT NULL,
  `cnpj` varchar(18) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `produto_servico` text NOT NULL,
  `valor` decimal(15,2) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `escrituracao`
--

INSERT INTO `escrituracao` (`id`, `tipo_nota`, `cnpj`, `razao_social`, `produto_servico`, `valor`, `data_cadastro`, `data_atualizacao`) VALUES
(1, 'Entrada', '52.782.164/0001-00', 'Ipiranga', 'Combustível', 26000.00, '2025-09-23 23:16:33', '2025-09-23 23:16:33'),
(2, 'Serviços Tomados', '18.730.562/0001-25', 'ContAÍ LTDA.', 'Sistema para Contabilidade e Assistência Tributária', 500.00, '2025-09-23 23:24:59', '2025-09-23 23:24:59'),
(3, 'Entrada', '55.666.777/0001-88', 'Comercial Delta ME', 'Teste', 1000.00, '2025-12-27 23:16:31', '2025-12-27 23:16:31');

-- --------------------------------------------------------

--
-- Estrutura para tabela `prestadores`
--

CREATE TABLE `prestadores` (
  `id` int(11) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `cnpj` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `prestadores`
--

INSERT INTO `prestadores` (`id`, `razao_social`, `cnpj`) VALUES
(2, 'Ipiranga', '52.782.164/0001-00'),
(3, 'ContAÍ LTDA.', '18.730.562/0001-25'),
(4, 'ABC Serviços Ltda', '12.345.678/0001-90'),
(5, 'XYZ Consultoria S.A.', '98.765.432/0001-10'),
(6, 'TechSolutions Informática', '11.222.333/0001-44'),
(8, 'Rafael Policiano da Silva - PF', '54.758.960/0001-80'),
(9, 'ABC Serviços Ltda', '12.345.678/0001-90'),
(10, 'XYZ Consultoria S.A.', '98.765.432/0001-10'),
(11, 'TechSolutions Informática', '11.222.333/0001-44'),
(12, 'Comercial Delta ME', '55.666.777/0001-88');

--
-- Acionadores `prestadores`
--
DELIMITER $$
CREATE TRIGGER `trg_validar_cnpj_prestador` BEFORE INSERT ON `prestadores` FOR EACH ROW BEGIN
    IF LENGTH(REPLACE(REPLACE(NEW.cnpj, '.', ''), '/', '')) < 14 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'CNPJ inválido';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `senha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `senha`) VALUES
(1, 'Rafael', '123'),
(2, 'Gabi', '123'),
(3, 'Wagner', '4321'),
(4, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `vw_contas_atrasadas`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `vw_contas_atrasadas` (
`id` int(11)
,`tipo` enum('Conta a Pagar','Conta a Receber')
,`razao_social` varchar(255)
,`valor` decimal(15,2)
,`data_vencimento` date
,`dias_atraso` int(7)
,`multa_calculada` decimal(17,2)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `vw_resumo_financeiro`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `vw_resumo_financeiro` (
`total_a_receber` decimal(37,2)
,`total_a_pagar` decimal(37,2)
,`total_vencido_pagar` decimal(37,2)
,`total_multas` decimal(37,2)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `vw_tarefas_pendentes`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `vw_tarefas_pendentes` (
`id` int(11)
,`data_tarefa` date
,`tarefa` text
,`dias_restantes` int(7)
);

-- --------------------------------------------------------

--
-- Estrutura para view `vw_contas_atrasadas`
--
DROP TABLE IF EXISTS `vw_contas_atrasadas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_contas_atrasadas`  AS SELECT `contas`.`id` AS `id`, `contas`.`tipo` AS `tipo`, `contas`.`razao_social` AS `razao_social`, `contas`.`valor` AS `valor`, `contas`.`data_vencimento` AS `data_vencimento`, to_days(curdate()) - to_days(`contas`.`data_vencimento`) AS `dias_atraso`, round(`contas`.`valor` * 0.05,2) AS `multa_calculada` FROM `contas` WHERE `contas`.`data_vencimento` < curdate() AND `contas`.`status` = 'Pendente' ;

-- --------------------------------------------------------

--
-- Estrutura para view `vw_resumo_financeiro`
--
DROP TABLE IF EXISTS `vw_resumo_financeiro`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_resumo_financeiro`  AS SELECT (select coalesce(sum(`contas`.`valor`),0) from `contas` where `contas`.`tipo` = 'Conta a Receber' and `contas`.`status` = 'Pendente') AS `total_a_receber`, (select coalesce(sum(`contas`.`valor`),0) from `contas` where `contas`.`tipo` = 'Conta a Pagar' and `contas`.`status` = 'Pendente') AS `total_a_pagar`, (select coalesce(sum(`contas_vencidas`.`valor`),0) from `contas_vencidas` where `contas_vencidas`.`tipo_conta` = 'Conta a Pagar' and `contas_vencidas`.`status` = 'Pendente') AS `total_vencido_pagar`, (select coalesce(sum(`contas_vencidas`.`multa`),0) from `contas_vencidas` where `contas_vencidas`.`status` = 'Pendente') AS `total_multas` ;

-- --------------------------------------------------------

--
-- Estrutura para view `vw_tarefas_pendentes`
--
DROP TABLE IF EXISTS `vw_tarefas_pendentes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_tarefas_pendentes`  AS SELECT `agenda`.`id` AS `id`, `agenda`.`data_tarefa` AS `data_tarefa`, `agenda`.`tarefa` AS `tarefa`, to_days(`agenda`.`data_tarefa`) - to_days(curdate()) AS `dias_restantes` FROM `agenda` WHERE `agenda`.`status` = 'Pendente' AND `agenda`.`data_tarefa` >= curdate() ORDER BY `agenda`.`data_tarefa` ASC ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_data_tarefa` (`data_tarefa`),
  ADD KEY `idx_status` (`status`);

--
-- Índices de tabela `contas`
--
ALTER TABLE `contas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tipo` (`tipo`),
  ADD KEY `idx_data_vencimento` (`data_vencimento`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_cnpj` (`cnpj`);

--
-- Índices de tabela `contas_vencidas`
--
ALTER TABLE `contas_vencidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tipo_conta` (`tipo_conta`),
  ADD KEY `idx_cnpj` (`cnpj`),
  ADD KEY `idx_data_vencimento` (`data_vencimento`),
  ADD KEY `idx_status` (`status`);

--
-- Índices de tabela `escrituracao`
--
ALTER TABLE `escrituracao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tipo_nota` (`tipo_nota`),
  ADD KEY `idx_cnpj` (`cnpj`),
  ADD KEY `idx_data_cadastro` (`data_cadastro`),
  ADD KEY `idx_valor` (`valor`);

--
-- Índices de tabela `prestadores`
--
ALTER TABLE `prestadores`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `contas`
--
ALTER TABLE `contas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `contas_vencidas`
--
ALTER TABLE `contas_vencidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `escrituracao`
--
ALTER TABLE `escrituracao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `prestadores`
--
ALTER TABLE `prestadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
