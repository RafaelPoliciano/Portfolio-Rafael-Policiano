import tkinter as tk
from tkinter import filedialog, messagebox, font
import os

class EditorTexto:
    def __init__(self, root):
        self.root = root
        self.root.title("Editor de Texto")
        self.root.geometry("900x650")
        self.arquivo_atual = None
        self.modificado = False

        self._configurar_estilos()
        self._criar_menu()
        self._criar_barra_ferramentas()
        self._criar_area_texto()
        self._criar_barra_status()

        self.root.protocol("WM_DELETE_WINDOW", self.sair)
        self.root.bind("<Control-n>", lambda e: self.novo())
        self.root.bind("<Control-o>", lambda e: self.abrir())
        self.root.bind("<Control-s>", lambda e: self.salvar())
        self.root.bind("<Control-S>", lambda e: self.salvar_como())
        self.root.bind("<Control-z>", lambda e: self.desfazer())
        self.root.bind("<Control-y>", lambda e: self.refazer())
        self.root.bind("<Control-a>", lambda e: self.selecionar_tudo())
        self.root.bind("<Control-f>", lambda e: self.buscar())

    def _configurar_estilos(self):
        self.root.configure(bg="#1e1e2e")
        self.cor_fundo      = "#1e1e2e"
        self.cor_painel     = "#181825"
        self.cor_texto      = "#cdd6f4"
        self.cor_cursor     = "#f38ba8"
        self.cor_selecao    = "#313244"
        self.cor_barra      = "#11111b"
        self.cor_botao      = "#313244"
        self.cor_botao_fg   = "#cdd6f4"
        self.cor_status_fg  = "#a6adc8"
        self.cor_destaque   = "#89b4fa"
        self.fonte_editor   = ("Consolas", 13)
        self.fonte_ui       = ("Segoe UI", 10)

    def _criar_menu(self):
        barra_menu = tk.Menu(self.root, bg=self.cor_barra, fg=self.cor_texto,
                             activebackground=self.cor_botao, activeforeground=self.cor_destaque,
                             borderwidth=0, relief="flat")

        # Arquivo
        menu_arquivo = tk.Menu(barra_menu, tearoff=0, bg=self.cor_barra, fg=self.cor_texto,
                               activebackground=self.cor_botao, activeforeground=self.cor_destaque)
        menu_arquivo.add_command(label="Novo          Ctrl+N", command=self.novo)
        menu_arquivo.add_command(label="Abrir...      Ctrl+O", command=self.abrir)
        menu_arquivo.add_separator()
        menu_arquivo.add_command(label="Salvar        Ctrl+S", command=self.salvar)
        menu_arquivo.add_command(label="Salvar como   Ctrl+Shift+S", command=self.salvar_como)
        menu_arquivo.add_separator()
        menu_arquivo.add_command(label="Sair", command=self.sair)
        barra_menu.add_cascade(label="Arquivo", menu=menu_arquivo)

        # Editar
        menu_editar = tk.Menu(barra_menu, tearoff=0, bg=self.cor_barra, fg=self.cor_texto,
                              activebackground=self.cor_botao, activeforeground=self.cor_destaque)
        menu_editar.add_command(label="Desfazer      Ctrl+Z", command=self.desfazer)
        menu_editar.add_command(label="Refazer       Ctrl+Y", command=self.refazer)
        menu_editar.add_separator()
        menu_editar.add_command(label="Recortar      Ctrl+X", command=self.recortar)
        menu_editar.add_command(label="Copiar        Ctrl+C", command=self.copiar)
        menu_editar.add_command(label="Colar         Ctrl+V", command=self.colar)
        menu_editar.add_separator()
        menu_editar.add_command(label="Selecionar tudo  Ctrl+A", command=self.selecionar_tudo)
        menu_editar.add_command(label="Buscar...     Ctrl+F", command=self.buscar)
        barra_menu.add_cascade(label="Editar", menu=menu_editar)

        # Visualizar
        menu_ver = tk.Menu(barra_menu, tearoff=0, bg=self.cor_barra, fg=self.cor_texto,
                           activebackground=self.cor_botao, activeforeground=self.cor_destaque)
        menu_ver.add_command(label="Aumentar fonte  Ctrl++", command=self.aumentar_fonte)
        menu_ver.add_command(label="Diminuir fonte  Ctrl+-", command=self.diminuir_fonte)
        barra_menu.add_cascade(label="Visualizar", menu=menu_ver)

        self.root.config(menu=barra_menu)
        self.root.bind("<Control-equal>", lambda e: self.aumentar_fonte())
        self.root.bind("<Control-minus>", lambda e: self.diminuir_fonte())

    def _criar_barra_ferramentas(self):
        barra = tk.Frame(self.root, bg=self.cor_barra, pady=4, padx=6)
        barra.pack(fill="x", side="top")

        botoes = [
            ("📄 Novo",    self.novo),
            ("📂 Abrir",   self.abrir),
            ("💾 Salvar",  self.salvar),
            ("✂️ Recortar", self.recortar),
            ("📋 Copiar",  self.copiar),
            ("📌 Colar",   self.colar),
            ("↩ Desfazer", self.desfazer),
            ("↪ Refazer",  self.refazer),
            ("🔍 Buscar",  self.buscar),
        ]

        for label, cmd in botoes:
            btn = tk.Button(barra, text=label, command=cmd,
                            bg=self.cor_botao, fg=self.cor_botao_fg,
                            relief="flat", padx=8, pady=3,
                            font=self.fonte_ui, cursor="hand2",
                            activebackground=self.cor_selecao,
                            activeforeground=self.cor_destaque,
                            borderwidth=0)
            btn.pack(side="left", padx=2)

    def _criar_area_texto(self):
        frame = tk.Frame(self.root, bg=self.cor_fundo)
        frame.pack(fill="both", expand=True, padx=0, pady=0)

        # Números de linha
        self.numeros_linha = tk.Text(frame, width=4, padx=6, pady=8,
                                     bg=self.cor_painel, fg="#585b70",
                                     state="disabled", font=self.fonte_editor,
                                     relief="flat", borderwidth=0,
                                     selectbackground=self.cor_painel)
        self.numeros_linha.pack(side="left", fill="y")

        # Área de texto principal
        self.area_texto = tk.Text(frame, wrap="word", undo=True,
                                  bg=self.cor_fundo, fg=self.cor_texto,
                                  insertbackground=self.cor_cursor,
                                  selectbackground=self.cor_selecao,
                                  selectforeground=self.cor_texto,
                                  font=self.fonte_editor, relief="flat",
                                  padx=12, pady=8, borderwidth=0)
        self.area_texto.pack(fill="both", expand=True, side="left")

        scroll = tk.Scrollbar(frame, command=self._scroll_sincronizado,
                              bg=self.cor_barra, troughcolor=self.cor_fundo,
                              relief="flat", borderwidth=0)
        scroll.pack(side="right", fill="y")
        self.area_texto.config(yscrollcommand=scroll.set)

        self.area_texto.bind("<KeyRelease>", self._ao_modificar)
        self.area_texto.bind("<MouseWheel>", self._atualizar_numeros)
        self.area_texto.bind("<ButtonRelease>", self._atualizar_status)

        self._atualizar_numeros()

    def _scroll_sincronizado(self, *args):
        self.area_texto.yview(*args)
        self.numeros_linha.yview(*args)

    def _criar_barra_status(self):
        barra = tk.Frame(self.root, bg=self.cor_barra, pady=3, padx=10)
        barra.pack(fill="x", side="bottom")

        self.label_arquivo = tk.Label(barra, text="Sem título", bg=self.cor_barra,
                                      fg=self.cor_status_fg, font=self.fonte_ui)
        self.label_arquivo.pack(side="left")

        self.label_pos = tk.Label(barra, text="Ln 1, Col 1", bg=self.cor_barra,
                                  fg=self.cor_status_fg, font=self.fonte_ui)
        self.label_pos.pack(side="right")

        self.label_palavras = tk.Label(barra, text="0 palavras", bg=self.cor_barra,
                                       fg=self.cor_status_fg, font=self.fonte_ui)
        self.label_palavras.pack(side="right", padx=20)

    def _ao_modificar(self, event=None):
        self.modificado = True
        self._atualizar_titulo()
        self._atualizar_numeros()
        self._atualizar_status()

    def _atualizar_numeros(self, event=None):
        self.numeros_linha.config(state="normal")
        self.numeros_linha.delete("1.0", "end")
        total = int(self.area_texto.index("end-1c").split(".")[0])
        numeros = "\n".join(str(i) for i in range(1, total + 1))
        self.numeros_linha.insert("1.0", numeros)
        self.numeros_linha.config(state="disabled")
        self.numeros_linha.yview_moveto(self.area_texto.yview()[0])

    def _atualizar_status(self, event=None):
        pos = self.area_texto.index("insert")
        ln, col = pos.split(".")
        self.label_pos.config(text=f"Ln {ln}, Col {int(col)+1}")
        texto = self.area_texto.get("1.0", "end-1c")
        palavras = len(texto.split()) if texto.strip() else 0
        self.label_palavras.config(text=f"{palavras} palavra{'s' if palavras != 1 else ''}")

    def _atualizar_titulo(self):
        nome = os.path.basename(self.arquivo_atual) if self.arquivo_atual else "Sem título"
        modificado = " •" if self.modificado else ""
        self.root.title(f"{nome}{modificado} — Editor de Texto")
        self.label_arquivo.config(text=self.arquivo_atual or "Sem título")

    def _confirmar_descarte(self):
        if self.modificado:
            resp = messagebox.askyesnocancel("Salvar alterações",
                "Há alterações não salvas. Deseja salvar antes de continuar?")
            if resp is True:
                return self.salvar()
            elif resp is False:
                return True
            else:
                return False
        return True

    # ── Comandos ──────────────────────────────────────────────────────────────

    def novo(self):
        if not self._confirmar_descarte():
            return
        self.area_texto.delete("1.0", "end")
        self.arquivo_atual = None
        self.modificado = False
        self._atualizar_titulo()
        self._atualizar_numeros()
        self._atualizar_status()

    def abrir(self):
        if not self._confirmar_descarte():
            return
        caminho = filedialog.askopenfilename(
            filetypes=[("Arquivos de texto", "*.txt"), ("Todos os arquivos", "*.*")])
        if caminho:
            with open(caminho, "r", encoding="utf-8") as f:
                conteudo = f.read()
            self.area_texto.delete("1.0", "end")
            self.area_texto.insert("1.0", conteudo)
            self.arquivo_atual = caminho
            self.modificado = False
            self._atualizar_titulo()
            self._atualizar_numeros()
            self._atualizar_status()

    def salvar(self):
        if self.arquivo_atual:
            with open(self.arquivo_atual, "w", encoding="utf-8") as f:
                f.write(self.area_texto.get("1.0", "end-1c"))
            self.modificado = False
            self._atualizar_titulo()
            return True
        return self.salvar_como()

    def salvar_como(self):
        caminho = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Arquivos de texto", "*.txt"), ("Todos os arquivos", "*.*")])
        if caminho:
            self.arquivo_atual = caminho
            return self.salvar()
        return False

    def sair(self):
        if self._confirmar_descarte():
            self.root.destroy()

    def desfazer(self):
        try:
            self.area_texto.edit_undo()
        except Exception:
            pass

    def refazer(self):
        try:
            self.area_texto.edit_redo()
        except Exception:
            pass

    def recortar(self):
        self.area_texto.event_generate("<<Cut>>")

    def copiar(self):
        self.area_texto.event_generate("<<Copy>>")

    def colar(self):
        self.area_texto.event_generate("<<Paste>>")

    def selecionar_tudo(self):
        self.area_texto.tag_add("sel", "1.0", "end")
        return "break"

    def aumentar_fonte(self):
        tam = self.fonte_editor[1] + 1
        self.fonte_editor = (self.fonte_editor[0], tam)
        self.area_texto.config(font=self.fonte_editor)
        self.numeros_linha.config(font=self.fonte_editor)

    def diminuir_fonte(self):
        tam = max(8, self.fonte_editor[1] - 1)
        self.fonte_editor = (self.fonte_editor[0], tam)
        self.area_texto.config(font=self.fonte_editor)
        self.numeros_linha.config(font=self.fonte_editor)

    def buscar(self):
        janela = tk.Toplevel(self.root)
        janela.title("Buscar")
        janela.geometry("380x110")
        janela.configure(bg=self.cor_barra)
        janela.resizable(False, False)
        janela.transient(self.root)
        janela.grab_set()

        tk.Label(janela, text="Buscar:", bg=self.cor_barra, fg=self.cor_texto,
                 font=self.fonte_ui).grid(row=0, column=0, padx=12, pady=12, sticky="w")

        entrada = tk.Entry(janela, font=self.fonte_ui, bg=self.cor_botao,
                           fg=self.cor_texto, insertbackground=self.cor_cursor,
                           relief="flat", width=28)
        entrada.grid(row=0, column=1, padx=6, pady=12)
        entrada.focus()

        self.area_texto.tag_remove("busca", "1.0", "end")
        self.area_texto.tag_config("busca", background="#f9e2af", foreground="#1e1e2e")

        resultado = tk.Label(janela, text="", bg=self.cor_barra, fg=self.cor_status_fg,
                             font=self.fonte_ui)
        resultado.grid(row=2, column=0, columnspan=2, pady=4)

        def _buscar_texto():
            self.area_texto.tag_remove("busca", "1.0", "end")
            termo = entrada.get()
            if not termo:
                return
            idx = "1.0"
            count = 0
            while True:
                pos = self.area_texto.search(termo, idx, stopindex="end")
                if not pos:
                    break
                fim = f"{pos}+{len(termo)}c"
                self.area_texto.tag_add("busca", pos, fim)
                idx = fim
                count += 1
            resultado.config(text=f"{count} resultado(s) encontrado(s)" if count else "Não encontrado")
            if count:
                self.area_texto.see(self.area_texto.tag_ranges("busca")[0])

        tk.Button(janela, text="Buscar", command=_buscar_texto,
                  bg=self.cor_destaque, fg=self.cor_barra, font=self.fonte_ui,
                  relief="flat", padx=10, cursor="hand2").grid(row=0, column=2, padx=8)

        entrada.bind("<Return>", lambda e: _buscar_texto())
        janela.protocol("WM_DELETE_WINDOW", lambda: [
            self.area_texto.tag_remove("busca", "1.0", "end"), janela.destroy()])


if __name__ == "__main__":
    root = tk.Tk()
    app = EditorTexto(root)
    root.mainloop()