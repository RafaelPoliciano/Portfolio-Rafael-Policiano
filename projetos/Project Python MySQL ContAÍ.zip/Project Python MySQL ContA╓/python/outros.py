import mysql.connector
from tkinter import *
from tkinter import messagebox, ttk
from PIL import Image, ImageTk

# Configurações do banco de dados
config = {
    'user': 'root',
    'password': '',
    'host': '127.0.0.1',
    'database': 'meu_banco'
}

# --- Funções de login e registro ---
def verificar_login():
    usuario = entry_username.get()
    senha = entry_senha.get()
    if not usuario or not senha:
        messagebox.showwarning("Aviso", "Por favor, preencha todos os campos.")
        return
    try:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor()
        sql = "SELECT * FROM usuarios WHERE usuario = %s AND senha = %s"
        cursor.execute(sql, (usuario, senha))
        resultado = cursor.fetchone()
        if resultado:
            messagebox.showinfo("Sucesso", f"Bem-vindo, {usuario}!")
            login_frame.pack_forget()
            abrir_painel_principal()
        else:
            messagebox.showerror("Erro", "Usuário ou senha incorretos.")
    except mysql.connector.Error as err:
        messagebox.showerror("Erro de Banco", f"Erro: {err}")
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conn' in locals(): conn.close()

def registrar_usuario():
    usuario = entry_username.get()
    senha = entry_senha.get()
    if not usuario or not senha:
        messagebox.showwarning("Aviso", "Por favor, preencha todos os campos.")
        return
    try:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        if cursor.fetchone():
            messagebox.showerror("Erro", "Usuário já existe. Escolha outro nome.")
        else:
            sql = "INSERT INTO usuarios (usuario, senha) VALUES (%s, %s)"
            cursor.execute(sql, (usuario, senha))
            conn.commit()
            messagebox.showinfo("Sucesso", f"Usuário {usuario} registrado com sucesso!")
    except mysql.connector.Error as err:
        messagebox.showerror("Erro de Banco", f"Erro: {err}")
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conn' in locals(): conn.close()

# --- Função para centralizar janelas ---
def centralizar_janela(janela, largura=700, altura=500):
    largura_tela = janela.winfo_screenwidth()
    altura_tela = janela.winfo_screenheight()
    pos_x = (largura_tela // 2) - (largura // 2)
    pos_y = (altura_tela // 2) - (altura // 2)
    janela.geometry(f"{largura}x{altura}+{pos_x}+{pos_y}")

# --- Função para criar janelas temáticas ---
def criar_janela(titulo, texto):
    janela = Toplevel(root)
    janela.title(titulo)
    centralizar_janela(janela)
    janela.configure(bg="black")
    Label(janela, text=texto, font=("Arial", 14), bg="black", fg="white").pack(pady=20)
    return janela

# --- Funções para abrir cada janela ---
def abrir_contas_pagar_receber(): criar_janela("Contas a Pagar/Receber", "Tela de Contas a Pagar/Receber")
def abrir_contas_vencidas(): criar_janela("Contas Vencidas", "Tela de Contas Vencidas")
def abrir_informacoes_empresa(): criar_janela("Informações da Empresa", "Tela de Informações da Empresa")
def abrir_cadastro_clientes(): criar_janela("Cadastro de Clientes", "Tela de Cadastro de Clientes")

# --- Janela unificada para Contas a Pagar e Receber ---
def abrir_contas_pagar_receber():
    janela = Toplevel(root)
    janela.title("Contas a Pagar / Receber")
    centralizar_janela(janela, 600, 400)
    janela.configure(bg="black")

    Label(janela, text="Gerenciamento de Contas", font=("Arial", 14), bg="black", fg="white").pack(pady=10)

    frame_campos = Frame(janela, bg="black")
    frame_campos.pack(pady=10)

    # Seleção tipo de conta
    Label(frame_campos, text="Tipo de Conta:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="e")
    combo_tipo = ttk.Combobox(frame_campos, values=["Conta a Pagar", "Conta a Receber"], state="readonly", width=27)
    combo_tipo.grid(row=0, column=1, padx=10, pady=5)
    combo_tipo.current(0)

    # CNPJ
    Label(frame_campos, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_cnpj = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_cnpj.grid(row=1, column=1, padx=10, pady=5)

    # Razão Social
    Label(frame_campos, text="Razão Social:", font=("Arial", 12), bg="black", fg="white").grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_razao = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_razao.grid(row=2, column=1, padx=10, pady=5)

    # Valor
    Label(frame_campos, text="Valor (R$):", font=("Arial", 12), bg="black", fg="white").grid(row=3, column=0, padx=10, pady=5, sticky="e")
    entry_valor = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_valor.grid(row=3, column=1, padx=10, pady=5)

    # Data de Vencimento
    Label(frame_campos, text="Data de Vencimento (DD/MM/AAAA):", font=("Arial", 12), bg="black", fg="white").grid(row=4, column=0, padx=10, pady=5, sticky="e")
    entry_data = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_data.grid(row=4, column=1, padx=10, pady=5)

    # --- NOVA FUNÇÃO PARA BUSCAR RAZÃO SOCIAL ---
    def buscar_razao_social(event=None):
        cnpj = entry_cnpj.get().strip()
        
        if len(cnpj) < 14:
            entry_razao.delete(0, END)
            return

        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            cursor.execute("SELECT razao_social FROM prestadores WHERE cnpj = %s", (cnpj,))
            resultado = cursor.fetchone()
            
            entry_razao.delete(0, END)
            
            if resultado:
                entry_razao.insert(0, resultado[0])
            else:
                entry_razao.insert(0, "CNPJ não encontrado")
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao consultar CNPJ: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    entry_cnpj.bind('<KeyRelease>', buscar_razao_social)

    # --- Função para salvar ---
    def salvar():
        tipo = combo_tipo.get()
        cnpj = entry_cnpj.get().strip()
        razao = entry_razao.get().strip()
        valor_str = entry_valor.get().strip()
        data = entry_data.get().strip()

        if not tipo or not valor_str or not data:
            messagebox.showwarning("Aviso", "Os campos 'Tipo', 'Valor' e 'Data' são obrigatórios.")
            return

        if razao == "CNPJ não encontrado" or not razao:
            messagebox.showwarning("Aviso", "A razão social é inválida ou não foi encontrada.")
            return

        try:
            valor_float = float(valor_str.replace(',', '.'))
            if valor_float <= 0:
                messagebox.showwarning("Aviso", "O valor deve ser maior que zero.")
                return
        except ValueError:
            messagebox.showwarning("Aviso", "Digite um valor numérico válido.")
            return
        
        # Validação de data DD-MM-AAAA
        if len(data) != 10 or data[2] != '/' or data[5] != '/':
            messagebox.showwarning("Aviso", "Use o formato de data DD-MM-AAAA.")
            return

        dia, mes, ano = data.split('/')
        if not (dia.isdigit() and mes.isdigit() and ano.isdigit()):
            messagebox.showwarning("Aviso", "Data inválida. Use apenas números no formato DD-MM-AAAA.")
            return

        # Converte para AAAA-MM-DD antes de salvar no banco
        data_mysql = f"{ano}-{mes}-{dia}"

        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            
            sql = """INSERT INTO contas 
                     (tipo, cnpj, razao_social, valor, data_vencimento) 
                     VALUES (%s, %s, %s, %s, %s)"""
            
            cursor.execute(sql, (tipo, cnpj, razao, valor_float, data_mysql))
            conn.commit()
            
            messagebox.showinfo("Sucesso", "Conta registrada com sucesso!")
            limpar()

        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao salvar a conta: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    def limpar():
        combo_tipo.current(0)
        entry_cnpj.delete(0, END)
        entry_razao.delete(0, END)
        entry_valor.delete(0, END)
        entry_data.delete(0, END)

    # Botões
    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=15)
    Button(frame_botoes, text="Salvar", width=15, command=salvar, bg="gray30", fg="white").grid(row=0, column=0, padx=10)
    Button(frame_botoes, text="Limpar", width=15, command=limpar, bg="gray30", fg="white").grid(row=0, column=1, padx=10)


 # --- Contas Vencidas ---
def abrir_contas_vencidas():
    janela = Toplevel(root)
    janela.title("Contas Vencidas")
    centralizar_janela(janela, 650, 550)
    janela.configure(bg="black")

    # Título
    Label(janela, text="Contas Vencidas", font=("Arial", 16), bg="black", fg="white").pack(pady=15)

    # Frame principal para organizar os campos
    frame_principal = Frame(janela, bg="black")
    frame_principal.pack(pady=10, padx=20, fill="both", expand=True)

    # --- Tipo de Conta ---
    Label(frame_principal, text="Tipo de Conta:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=10, sticky="w")
    
    tipo_var = StringVar()
    tipo_combobox = ttk.Combobox(frame_principal, textvariable=tipo_var, width=25, state="readonly")
    tipo_combobox['values'] = ('Conta a Pagar', 'Conta a Receber')
    tipo_combobox.grid(row=0, column=1, padx=10, pady=10, sticky="w")
    tipo_combobox.set('Conta a Pagar')  # Valor padrão

    # --- CNPJ ---
    Label(frame_principal, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    entry_cnpj = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_cnpj.grid(row=1, column=1, padx=10, pady=10, sticky="w")

    # --- Razão Social (automática) ---
    Label(frame_principal, text="Razão Social:", font=("Arial", 12), bg="black", fg="white").grid(row=2, column=0, padx=10, pady=10, sticky="w")
    razao_social_var = StringVar()
    label_razao_social = Label(frame_principal, textvariable=razao_social_var, font=("Arial", 11), 
                              bg="gray20", fg="white", width=28, height=2, anchor="w", 
                              relief="sunken", bd=1, wraplength=250)
    label_razao_social.grid(row=2, column=1, padx=10, pady=10, sticky="w")

    # --- Função para buscar razão social por CNPJ ---
    def buscar_razao_social(event=None):
        cnpj = entry_cnpj.get().strip()
        if len(cnpj) >= 14:  # CNPJ tem 14 dígitos
            try:
                conn = mysql.connector.connect(**config)
                cursor = conn.cursor()
                cursor.execute("SELECT razao_social FROM prestadores WHERE cnpj = %s", (cnpj,))
                resultado = cursor.fetchone()
                if resultado:
                    razao_social_var.set(resultado[0])
                else:
                    razao_social_var.set("CNPJ não encontrado no sistema")
            except mysql.connector.Error as err:
                razao_social_var.set(f"Erro ao consultar: {err}")
            finally:
                if 'cursor' in locals(): 
                    cursor.close()
                if 'conn' in locals(): 
                    conn.close()
        else:
            razao_social_var.set("")

    # Vincular a função de busca ao evento de digitação no campo CNPJ
    entry_cnpj.bind('<KeyRelease>', buscar_razao_social)

    # --- Valor ---
    Label(frame_principal, text="Valor (R$):", font=("Arial", 12), bg="black", fg="white").grid(row=3, column=0, padx=10, pady=10, sticky="w")
    entry_valor = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_valor.grid(row=3, column=1, padx=10, pady=10, sticky="w")

    # --- Multa (5% automático) ---
    Label(frame_principal, text="Multa (5%):", font=("Arial", 12), bg="black", fg="white").grid(row=4, column=0, padx=10, pady=10, sticky="w")
    multa_var = StringVar()
    multa_var.set("R$ 0,00")
    label_multa = Label(frame_principal, textvariable=multa_var, font=("Arial", 11, "bold"), 
                       bg="gray20", fg="yellow", width=28, height=1, anchor="w", 
                       relief="sunken", bd=1)
    label_multa.grid(row=4, column=1, padx=10, pady=10, sticky="w")

    # --- Data de Vencimento ---
    Label(frame_principal, text="Data de Vencimento:", font=("Arial", 12), bg="black", fg="white").grid(row=5, column=0, padx=10, pady=10, sticky="w")
    entry_data = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_data.grid(row=5, column=1, padx=10, pady=10, sticky="w")
    
    # Placeholder para formato de data
    Label(frame_principal, text="(formato: DD/MM/AAAA)", font=("Arial", 9), bg="black", fg="gray").grid(row=5, column=2, padx=5, sticky="w")

    # --- Função para calcular multa ---
    def calcular_multa(event=None):
        valor = entry_valor.get().strip()
        if valor:
            try:
                valor_float = float(valor.replace(',', '.'))
                multa = valor_float * 0.05
                multa_var.set(f"R$ {multa:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
            except ValueError:
                multa_var.set("R$ 0,00")
        else:
            multa_var.set("R$ 0,00")

    # --- Função para validar entrada numérica no valor ---
    def validar_valor(event=None):
        valor = entry_valor.get()
        # Remove caracteres que não sejam números, vírgula ou ponto
        valor_limpo = ''.join(c for c in valor if c.isdigit() or c in '.,')
        if valor != valor_limpo:
            entry_valor.delete(0, END)
            entry_valor.insert(0, valor_limpo)
        # Calcular multa sempre que o valor mudar
        calcular_multa()

    # Vincular validação ao campo valor
    entry_valor.bind('<KeyRelease>', validar_valor)

    # --- Função para validar data ---
    def validar_data(event=None):
        data = entry_data.get()
        # Remove caracteres que não sejam números ou /
        data_limpa = ''.join(c for c in data if c.isdigit() or c == '/')
        if data != data_limpa:
            entry_data.delete(0, END)
            entry_data.insert(0, data_limpa)

    # Vincular validação ao campo data
    entry_data.bind('<KeyRelease>', validar_data)

    # --- Função para salvar conta ---
    def salvar_conta():
        tipo = tipo_var.get()
        cnpj = entry_cnpj.get().strip()
        razao = razao_social_var.get()
        valor = entry_valor.get().strip()
        data_venc = entry_data.get().strip()

        # Validações básicas
        if not tipo:
            messagebox.showwarning("Aviso", "Selecione o tipo de conta.")
            return
        
        if not cnpj:
            messagebox.showwarning("Aviso", "Digite o CNPJ.")
            return
            
        if razao == "CNPJ não encontrado no sistema" or not razao:
            messagebox.showwarning("Aviso", "CNPJ não está cadastrado no sistema.")
            return
            
        if not valor:
            messagebox.showwarning("Aviso", "Digite o valor.")
            return
            
        if not data_venc:
            messagebox.showwarning("Aviso", "Digite a data de vencimento.")
            return
            
        # Validar se o valor é um número válido
        try:
            valor_float = float(valor.replace(',', '.'))
            if valor_float <= 0:
                messagebox.showwarning("Aviso", "O valor deve ser maior que zero.")
                return
        except ValueError:
            messagebox.showwarning("Aviso", "Digite um valor numérico válido.")
            return

        # Validar formato da data
        from datetime import datetime
        try:
            data_obj = datetime.strptime(data_venc, "%d/%m/%Y")
            data_sql = data_obj.strftime("%Y-%m-%d")  # Converter para formato SQL
        except ValueError:
            messagebox.showwarning("Aviso", "Data inválida. Use o formato DD/MM/AAAA.")
            return

        # Calcular multa
        multa_float = valor_float * 0.05

        # Salvar no banco de dados
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            
            sql = """INSERT INTO contas_vencidas 
                     (tipo_conta, cnpj, razao_social, valor, multa, data_vencimento) 
                     VALUES (%s, %s, %s, %s, %s, %s)"""
            
            cursor.execute(sql, (tipo, cnpj, razao, valor_float, multa_float, data_sql))
            conn.commit()
            
            # Pegar o ID da conta inserida
            conta_id = cursor.lastrowid
            
            messagebox.showinfo("Sucesso", 
                              f"Conta vencida #{conta_id} registrada com sucesso!\n\n"
                              f"Tipo: {tipo}\n"
                              f"CNPJ: {cnpj}\n"
                              f"Razão Social: {razao}\n"
                              f"Valor: R$ {valor}\n"
                              f"Multa: R$ {multa_float:.2f}\n"
                              f"Vencimento: {data_venc}")
            
            # Limpar os campos após salvar
            tipo_combobox.set('Conta a Pagar')
            entry_cnpj.delete(0, END)
            razao_social_var.set("")
            entry_valor.delete(0, END)
            entry_data.delete(0, END)
            multa_var.set("R$ 0,00")
            
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao salvar conta vencida: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    # --- Função para limpar campos ---
    def limpar_campos():
        tipo_combobox.set('Conta a Pagar')
        entry_cnpj.delete(0, END)
        razao_social_var.set("")
        entry_valor.delete(0, END)
        entry_data.delete(0, END)
        multa_var.set("R$ 0,00")

    # --- Botões ---
    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=20)

    Button(frame_botoes, text="Salvar Conta", width=15, command=salvar_conta, 
           bg="green", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=20)
    
    Button(frame_botoes, text="Limpar", width=15, command=limpar_campos, 
           bg="orange", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=1, padx=20)

    # --- Informações adicionais ---
    frame_info = Frame(janela, bg="black")
    frame_info.pack(pady=10)
    
    Label(frame_info, text="💡 Digite o CNPJ para buscar automaticamente a razão social", 
          font=("Arial", 9), bg="black", fg="gray").pack()
    
# --- Agenda de Prazos ---
def abrir_agenda_prazos():
    import calendar
    from datetime import datetime
    
    janela = Toplevel(root)
    janela.title("Agenda de Prazos")
    centralizar_janela(janela, 800, 600)
    janela.configure(bg="black")

    # Título
    Label(janela, text="Agenda de Prazos", font=("Arial", 16), bg="black", fg="white").pack(pady=15)

    # Frame principal dividido em duas partes
    frame_principal = Frame(janela, bg="black")
    frame_principal.pack(fill="both", expand=True, padx=20)

    # Frame esquerdo - Calendário
    frame_calendario = Frame(frame_principal, bg="black", width=400)
    frame_calendario.pack(side="left", fill="both", expand=True, padx=(0, 10))
    
    # Frame direito - Tarefas
    frame_tarefas = Frame(frame_principal, bg="black", width=350)
    frame_tarefas.pack(side="right", fill="both", expand=True, padx=(10, 0))

    # Variáveis globais para o calendário
    mes_atual = 9  # Setembro
    ano_atual = 2025
    data_selecionada = None
    tarefas = {}  # Cache local das tarefas

    # Função para carregar tarefas do banco
    def carregar_tarefas():
        nonlocal tarefas
        tarefas = {}
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            cursor.execute("SELECT data_tarefa, tarefa FROM agenda ORDER BY data_tarefa, data_cadastro")
            resultados = cursor.fetchall()
            
            for data_tarefa, tarefa in resultados:
                data_str = data_tarefa.strftime("%Y-%m-%d")
                if data_str not in tarefas:
                    tarefas[data_str] = []
                tarefas[data_str].append(tarefa)
                
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao carregar tarefas: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    # Função para salvar tarefa no banco
    def salvar_tarefa(data, tarefa):
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            sql = "INSERT INTO agenda (data_tarefa, tarefa) VALUES (%s, %s)"
            cursor.execute(sql, (data, tarefa))
            conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao salvar tarefa: {err}")
            return False
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()
        return True

    # Função para remover tarefa do banco
    def remover_tarefa_banco(data, tarefa):
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            # Remove a primeira ocorrência da tarefa nesta data
            sql = "DELETE FROM agenda WHERE data_tarefa = %s AND tarefa = %s LIMIT 1"
            cursor.execute(sql, (data, tarefa))
            conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao remover tarefa: {err}")
            return False
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()
        return True

    # Função para criar o calendário
    def criar_calendario():
        nonlocal data_selecionada
        
        # Limpar frame do calendário
        for widget in frame_calendario.winfo_children():
            widget.destroy()
            
        # Nomes dos meses em português
        meses_pt = {
            1: "Janeiro", 2: "Fevereiro", 3: "Março", 4: "Abril",
            5: "Maio", 6: "Junho", 7: "Julho", 8: "Agosto",
            9: "Setembro", 10: "Outubro", 11: "Novembro", 12: "Dezembro"
        }
        
        # Cabeçalho do mês/ano
        mes_nome = meses_pt[mes_atual]
        label_mes = Label(frame_calendario, text=f"{mes_nome} {ano_atual}", 
                         font=("Arial", 14, "bold"), bg="black", fg="white")
        label_mes.pack(pady=10)
        
        # Botões de navegação
        frame_nav = Frame(frame_calendario, bg="black")
        frame_nav.pack()
        
        def mes_anterior():
            nonlocal mes_atual, ano_atual
            mes_atual -= 1
            if mes_atual < 9:  # Não permite antes de setembro
                mes_atual = 9
            if mes_atual == 12 and ano_atual == 2024:  # Não permite dezembro de 2024
                mes_atual = 9
                ano_atual = 2025
            criar_calendario()
            
        def proximo_mes():
            nonlocal mes_atual, ano_atual
            mes_atual += 1
            if mes_atual > 12:  # Não permite depois de dezembro
                mes_atual = 12
            if mes_atual > 12:  # Reset para próximo ano se necessário
                mes_atual = 1
                ano_atual += 1
            if ano_atual > 2025:  # Limita até 2025
                mes_atual = 12
                ano_atual = 2025
            criar_calendario()
        
        Button(frame_nav, text="◀", command=mes_anterior, bg="gray30", fg="white", width=3).pack(side="left", padx=5)
        Button(frame_nav, text="▶", command=proximo_mes, bg="gray30", fg="white", width=3).pack(side="right", padx=5)
        
        # Grade do calendário
        frame_grade = Frame(frame_calendario, bg="black")
        frame_grade.pack(pady=20)
        
        # Cabeçalhos dos dias da semana em português
        dias_semana = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]
        for i, dia in enumerate(dias_semana):
            Label(frame_grade, text=dia, font=("Arial", 10, "bold"), 
                  bg="gray40", fg="white", width=8, height=2).grid(row=0, column=i, padx=1, pady=1)
        
        # Obter calendário do mês
        cal = calendar.monthcalendar(ano_atual, mes_atual)
        
        # Função para selecionar data
        def selecionar_data(dia):
            nonlocal data_selecionada
            if dia > 0:  # Apenas dias válidos
                data_selecionada = f"{ano_atual}-{mes_atual:02d}-{dia:02d}"
                criar_calendario()  # Recriar para destacar seleção
                mostrar_tarefas_data()
        
        # Criar botões para cada dia
        for semana_num, semana in enumerate(cal, start=1):
            for dia_num, dia in enumerate(semana):
                if dia == 0:  # Dias vazios
                    Label(frame_grade, text="", bg="black", width=8, height=3).grid(
                        row=semana_num, column=dia_num, padx=1, pady=1)
                else:
                    data_str = f"{ano_atual}-{mes_atual:02d}-{dia:02d}"
                    
                    # Definir cor do botão
                    if data_str == data_selecionada:
                        cor_fundo = "lightblue"
                        cor_texto = "black"
                    elif data_str in tarefas and tarefas[data_str]:
                        cor_fundo = "darkgreen"
                        cor_texto = "white"
                    else:
                        cor_fundo = "gray20"
                        cor_texto = "white"
                    
                    btn = Button(frame_grade, text=str(dia), 
                               command=lambda d=dia: selecionar_data(d),
                               bg=cor_fundo, fg=cor_texto, width=6, height=2,
                               font=("Arial", 10))
                    btn.grid(row=semana_num, column=dia_num, padx=1, pady=1)

    # Função para mostrar tarefas da data selecionada
    def mostrar_tarefas_data():
        # Limpar frame de tarefas
        for widget in frame_tarefas.winfo_children():
            widget.destroy()
            
        if not data_selecionada:
            Label(frame_tarefas, text="Selecione uma data no calendário", 
                  font=("Arial", 12), bg="black", fg="gray").pack(pady=50)
            return
            
        # Formatear data para exibição
        try:
            data_obj = datetime.strptime(data_selecionada, "%Y-%m-%d")
            data_formatada = data_obj.strftime("%d/%m/%Y")
        except:
            data_formatada = data_selecionada
            
        # Título da seção de tarefas
        Label(frame_tarefas, text=f"Tarefas para {data_formatada}", 
              font=("Arial", 14, "bold"), bg="black", fg="white").pack(pady=10)
        
        # Campo para nova tarefa
        frame_nova_tarefa = Frame(frame_tarefas, bg="black")
        frame_nova_tarefa.pack(fill="x", pady=10)
        
        Label(frame_nova_tarefa, text="Nova Tarefa:", font=("Arial", 11), 
              bg="black", fg="white").pack(anchor="w")
        
        entry_tarefa = Entry(frame_nova_tarefa, bg="gray20", fg="white", 
                           insertbackground="white", font=("Arial", 11))
        entry_tarefa.pack(fill="x", pady=5)
        
        # Função para adicionar tarefa
        def adicionar_tarefa():
            texto_tarefa = entry_tarefa.get().strip()
            if texto_tarefa:
                # Salvar no banco de dados
                if salvar_tarefa(data_selecionada, texto_tarefa):
                    # Atualizar cache local
                    if data_selecionada not in tarefas:
                        tarefas[data_selecionada] = []
                    tarefas[data_selecionada].append(texto_tarefa)
                    entry_tarefa.delete(0, END)
                    mostrar_tarefas_data()
                    criar_calendario()  # Atualizar cores do calendário
            else:
                messagebox.showwarning("Aviso", "Digite uma tarefa para adicionar.")
        
        # Permitir adicionar tarefa com Enter
        def adicionar_enter(event=None):
            adicionar_tarefa()
        
        entry_tarefa.bind('<Return>', adicionar_enter)
        
        # Botão adicionar
        Button(frame_nova_tarefa, text="Adicionar Tarefa", command=adicionar_tarefa,
               bg="green", fg="white", font=("Arial", 10)).pack(pady=5)
        
        # Lista de tarefas existentes
        frame_lista = Frame(frame_tarefas, bg="black")
        frame_lista.pack(fill="both", expand=True, pady=10)
        
        if data_selecionada in tarefas and tarefas[data_selecionada]:
            Label(frame_lista, text="Tarefas do Dia:", font=("Arial", 11, "bold"), 
                  bg="black", fg="white").pack(anchor="w", pady=(0, 10))
            
            # Scroll para lista de tarefas
            canvas_tarefas = Canvas(frame_lista, bg="black", highlightthickness=0, height=200)
            scrollbar_tarefas = Scrollbar(frame_lista, orient="vertical", command=canvas_tarefas.yview)
            frame_scroll_tarefas = Frame(canvas_tarefas, bg="black")
            
            frame_scroll_tarefas.bind("<Configure>", 
                                    lambda e: canvas_tarefas.configure(scrollregion=canvas_tarefas.bbox("all")))
            
            canvas_tarefas.create_window((0, 0), window=frame_scroll_tarefas, anchor="nw")
            canvas_tarefas.configure(yscrollcommand=scrollbar_tarefas.set)
            
            canvas_tarefas.pack(side="left", fill="both", expand=True)
            scrollbar_tarefas.pack(side="right", fill="y")
            
            # Função para remover tarefa
            def remover_tarefa(indice):
                if messagebox.askyesno("Confirmação", "Deseja remover esta tarefa?"):
                    tarefa_texto = tarefas[data_selecionada][indice]
                    
                    # Remover do banco de dados
                    if remover_tarefa_banco(data_selecionada, tarefa_texto):
                        # Atualizar cache local
                        tarefas[data_selecionada].pop(indice)
                        if not tarefas[data_selecionada]:  # Se não há mais tarefas
                            del tarefas[data_selecionada]
                        mostrar_tarefas_data()
                        criar_calendario()
            
            # Mostrar cada tarefa
            for i, tarefa in enumerate(tarefas[data_selecionada]):
                frame_item = Frame(frame_scroll_tarefas, bg="gray30", relief="raised", bd=1)
                frame_item.pack(fill="x", pady=2, padx=5)
                
                Label(frame_item, text=f"• {tarefa}", font=("Arial", 10), 
                      bg="gray30", fg="white", anchor="w", wraplength=250).pack(side="left", fill="x", expand=True, padx=10, pady=5)
                
                Button(frame_item, text="✕", command=lambda idx=i: remover_tarefa(idx),
                       bg="red", fg="white", width=3, font=("Arial", 8, "bold")).pack(side="right", padx=5)
        else:
            Label(frame_lista, text="Nenhuma tarefa para este dia", 
                  font=("Arial", 11), bg="black", fg="gray").pack(pady=50)
    
    # Legenda
    frame_legenda = Frame(janela, bg="black")
    frame_legenda.pack(pady=10)
    
    Label(frame_legenda, text="Legenda:", font=("Arial", 10, "bold"), bg="black", fg="white").pack()
    
    frame_cores = Frame(frame_legenda, bg="black")
    frame_cores.pack()
    
    Label(frame_cores, text="▓", font=("Arial", 12), bg="black", fg="lightblue").pack(side="left")
    Label(frame_cores, text="Selecionado", font=("Arial", 9), bg="black", fg="white").pack(side="left", padx=(2, 15))
    
    Label(frame_cores, text="▓", font=("Arial", 12), bg="black", fg="darkgreen").pack(side="left")
    Label(frame_cores, text="Com tarefas", font=("Arial", 9), bg="black", fg="white").pack(side="left", padx=(2, 15))
    
    Label(frame_cores, text="▓", font=("Arial", 12), bg="black", fg="gray20").pack(side="left")
    Label(frame_cores, text="Sem tarefas", font=("Arial", 9), bg="black", fg="white").pack(side="left", padx=2)
    
    # Carregar tarefas existentes do banco e inicializar calendário
    carregar_tarefas()
    criar_calendario()
    mostrar_tarefas_data()

# --- Pesquisa de Notas Fiscais ---
def abrir_pesquisa_notas():
    janela = Toplevel(root)
    janela.title("Pesquisa de Notas Fiscais")
    centralizar_janela(janela, 700, 500)
    janela.configure(bg="black")

    # Título
    Label(janela, text="Pesquisa de Notas Fiscais", font=("Arial", 16), bg="black", fg="white").pack(pady=15)

    # Frame de pesquisa
    frame_pesquisa = Frame(janela, bg="black")
    frame_pesquisa.pack(pady=10)

    Label(frame_pesquisa, text="ID da Nota:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="e")
    entry_id = Entry(frame_pesquisa, width=20, bg="gray20", fg="white", insertbackground="white", font=("Arial", 12))
    entry_id.grid(row=0, column=1, padx=10, pady=5)

    # Frame para exibir os resultados
    frame_resultado = Frame(janela, bg="black", relief="sunken", bd=2)
    frame_resultado.pack(pady=20, padx=20, fill="both", expand=True)

    # Labels para mostrar os dados da nota
    labels_resultado = {}
    campos = [
        ("ID da Nota:", "id"),
        ("Tipo de Nota:", "tipo"),
        ("CNPJ:", "cnpj"), 
        ("Razão Social:", "razao"),
        ("Produto/Serviço:", "produto"),
        ("Valor:", "valor"),
        ("Data de Cadastro:", "data_cadastro"),
        ("Última Atualização:", "data_atualizacao")
    ]

    for i, (label_text, campo) in enumerate(campos):
        # Label do campo
        Label(frame_resultado, text=label_text, font=("Arial", 11, "bold"), 
              bg="black", fg="white").grid(row=i, column=0, padx=15, pady=8, sticky="w")
        
        # Label para o valor (inicialmente vazio)
        label_valor = Label(frame_resultado, text="", font=("Arial", 11), 
                           bg="gray20", fg="white", width=50, anchor="w", 
                           relief="sunken", bd=1, wraplength=400)
        label_valor.grid(row=i, column=1, padx=15, pady=8, sticky="w")
        labels_resultado[campo] = label_valor

    # Função para pesquisar nota
    def pesquisar_nota():
        id_nota = entry_id.get().strip()
        
        # Limpar resultados anteriores
        for label in labels_resultado.values():
            label.config(text="", bg="gray20")
            
        if not id_nota:
            messagebox.showwarning("Aviso", "Digite o ID da nota fiscal.")
            return
            
        # Validar se é um número
        try:
            id_nota_int = int(id_nota)
        except ValueError:
            messagebox.showwarning("Aviso", "Digite um ID válido (apenas números).")
            return

        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            
            sql = """SELECT id, tipo_nota, cnpj, razao_social, produto_servico, 
                           valor, data_cadastro, data_atualizacao 
                     FROM escrituracao WHERE id = %s"""
            
            cursor.execute(sql, (id_nota_int,))
            resultado = cursor.fetchone()
            
            if resultado:
                # Desempacotar os dados
                id_db, tipo, cnpj, razao, produto, valor, data_cad, data_att = resultado
                
                # Formatar os dados para exibição
                labels_resultado["id"].config(text=f"#{id_db}", bg="lightgreen")
                labels_resultado["tipo"].config(text=tipo)
                labels_resultado["cnpj"].config(text=cnpj)
                labels_resultado["razao"].config(text=razao)
                labels_resultado["produto"].config(text=produto)
                labels_resultado["valor"].config(text=f"R$ {valor:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
                labels_resultado["data_cadastro"].config(text=data_cad.strftime("%d/%m/%Y às %H:%M:%S") if data_cad else "N/A")
                labels_resultado["data_atualizacao"].config(text=data_att.strftime("%d/%m/%Y às %H:%M:%S") if data_att else "N/A")
                
            else:
                # Nota não encontrada
                labels_resultado["id"].config(text="NOTA NÃO ENCONTRADA", bg="red", fg="white")
                messagebox.showinfo("Resultado", f"Nenhuma nota fiscal encontrada com o ID #{id_nota}.")
                
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao pesquisar nota: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    # Função para limpar pesquisa
    def limpar_pesquisa():
        entry_id.delete(0, END)
        for label in labels_resultado.values():
            label.config(text="", bg="gray20")

    # Permitir pesquisa ao pressionar Enter
    def pesquisar_enter(event=None):
        pesquisar_nota()
    
    entry_id.bind('<Return>', pesquisar_enter)

    # Botões
    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=15)

    Button(frame_botoes, text="🔍 Pesquisar", width=15, command=pesquisar_nota, 
           bg="blue", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=10)
    
    Button(frame_botoes, text="🗑️ Limpar", width=15, command=limpar_pesquisa, 
           bg="orange", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=1, padx=10)

    # Instrução
    Label(janela, text="💡 Digite o ID da nota e pressione Enter ou clique em Pesquisar", 
          font=("Arial", 9), bg="black", fg="gray").pack(pady=5)

# --- Escrituração de Notas Fiscais ---
def abrir_escrituracao_notas():
    janela = Toplevel(root)
    janela.title("Escrituração de Notas Fiscais")
    centralizar_janela(janela, 650, 450)
    janela.configure(bg="black")

    # Título
    Label(janela, text="Escrituração de Notas Fiscais", font=("Arial", 16), bg="black", fg="white").pack(pady=15)

    # Frame principal para organizar os campos
    frame_principal = Frame(janela, bg="black")
    frame_principal.pack(pady=10, padx=20, fill="both", expand=True)

    # --- Tipo de Nota ---
    Label(frame_principal, text="Tipo de Nota:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=10, sticky="w")
    
    tipo_var = StringVar()
    tipo_combobox = ttk.Combobox(frame_principal, textvariable=tipo_var, width=25, state="readonly")
    tipo_combobox['values'] = ('Entrada', 'Saída', 'Serviços Tomados')
    tipo_combobox.grid(row=0, column=1, padx=10, pady=10, sticky="w")
    tipo_combobox.set('Entrada')  # Valor padrão

    # --- CNPJ ---
    Label(frame_principal, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    entry_cnpj = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_cnpj.grid(row=1, column=1, padx=10, pady=10, sticky="w")

    # --- Razão Social (automática) ---
    Label(frame_principal, text="Razão Social:", font=("Arial", 12), bg="black", fg="white").grid(row=2, column=0, padx=10, pady=10, sticky="w")
    razao_social_var = StringVar()
    label_razao_social = Label(frame_principal, textvariable=razao_social_var, font=("Arial", 11), 
                              bg="gray20", fg="white", width=35, height=2, anchor="w", 
                              relief="sunken", bd=1, wraplength=250)
    label_razao_social.grid(row=2, column=1, padx=10, pady=10, sticky="w")

    # --- Produto/Serviço ---
    Label(frame_principal, text="Produto/Serviço:", font=("Arial", 12), bg="black", fg="white").grid(row=3, column=0, padx=10, pady=10, sticky="w")
    entry_produto = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_produto.grid(row=3, column=1, padx=10, pady=10, sticky="w")

    # --- Valor da Nota ---
    Label(frame_principal, text="Valor da Nota (R$):", font=("Arial", 12), bg="black", fg="white").grid(row=4, column=0, padx=10, pady=10, sticky="w")
    entry_valor = Entry(frame_principal, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_valor.grid(row=4, column=1, padx=10, pady=10, sticky="w")

    # --- Função para buscar razão social por CNPJ ---
    def buscar_razao_social(event=None):
        cnpj = entry_cnpj.get().strip()
        if len(cnpj) >= 14:  # CNPJ tem 14 dígitos
            try:
                conn = mysql.connector.connect(**config)
                cursor = conn.cursor()
                cursor.execute("SELECT razao_social FROM prestadores WHERE cnpj = %s", (cnpj,))
                resultado = cursor.fetchone()
                if resultado:
                    razao_social_var.set(resultado[0])
                else:
                    razao_social_var.set("CNPJ não encontrado no sistema")
            except mysql.connector.Error as err:
                razao_social_var.set(f"Erro ao consultar: {err}")
            finally:
                if 'cursor' in locals(): 
                    cursor.close()
                if 'conn' in locals(): 
                    conn.close()
        else:
            razao_social_var.set("")

    # Vincular a função de busca ao evento de digitação no campo CNPJ
    entry_cnpj.bind('<KeyRelease>', buscar_razao_social)

    # --- Função para salvar nota ---
    def salvar_nota():
        tipo = tipo_var.get()
        cnpj = entry_cnpj.get().strip()
        razao = razao_social_var.get()
        produto = entry_produto.get().strip()
        valor = entry_valor.get().strip()

        # Validações básicas
        if not tipo:
            messagebox.showwarning("Aviso", "Selecione o tipo de nota.")
            return
        
        if not cnpj:
            messagebox.showwarning("Aviso", "Digite o CNPJ.")
            return
            
        if razao == "CNPJ não encontrado no sistema" or not razao:
            messagebox.showwarning("Aviso", "CNPJ não está cadastrado no sistema.")
            return
            
        if not produto:
            messagebox.showwarning("Aviso", "Digite o produto ou serviço.")
            return
            
        if not valor:
            messagebox.showwarning("Aviso", "Digite o valor da nota.")
            return
            
        # Validar se o valor é um número válido
        try:
            valor_float = float(valor.replace(',', '.'))
            if valor_float <= 0:
                messagebox.showwarning("Aviso", "O valor deve ser maior que zero.")
                return
        except ValueError:
            messagebox.showwarning("Aviso", "Digite um valor numérico válido.")
            return

        # Salvar no banco de dados
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            
            sql = """INSERT INTO escrituracao 
                     (tipo_nota, cnpj, razao_social, produto_servico, valor) 
                     VALUES (%s, %s, %s, %s, %s)"""
            
            cursor.execute(sql, (tipo, cnpj, razao, produto, valor_float))
            conn.commit()
            
            # Pegar o ID da nota fiscal inserida
            nota_id = cursor.lastrowid
            
            messagebox.showinfo("Sucesso", 
                              f"Nota fiscal #{nota_id} salva com sucesso!\n\n"
                              f"Tipo: {tipo}\n"
                              f"CNPJ: {cnpj}\n"
                              f"Empresa: {razao}\n"
                              f"Produto/Serviço: {produto}\n"
                              f"Valor: R$ {valor}")
            
            # Limpar os campos após salvar
            tipo_combobox.set('Entrada')
            entry_cnpj.delete(0, END)
            razao_social_var.set("")
            entry_produto.delete(0, END)
            entry_valor.delete(0, END)
            
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro ao salvar nota fiscal: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    # --- Função para cancelar/limpar ---
    def cancelar_nota():
        if messagebox.askyesno("Confirmação", "Deseja limpar todos os campos?"):
            tipo_combobox.set('Entrada')
            entry_cnpj.delete(0, END)
            razao_social_var.set("")
            entry_produto.delete(0, END)
            entry_valor.delete(0, END)

    # --- Função para validar entrada numérica no valor ---
    def validar_valor(event=None):
        valor = entry_valor.get()
        # Remove caracteres que não sejam números, vírgula ou ponto
        valor_limpo = ''.join(c for c in valor if c.isdigit() or c in '.,')
        if valor != valor_limpo:
            entry_valor.delete(0, END)
            entry_valor.insert(0, valor_limpo)

    # Vincular validação ao campo valor
    entry_valor.bind('<KeyRelease>', validar_valor)

    # --- Botões ---
    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=20)

    Button(frame_botoes, text="Salvar Nota", width=15, command=salvar_nota, 
           bg="green", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=20)
    
    Button(frame_botoes, text="Cancelar", width=15, command=cancelar_nota, 
           bg="red", fg="white", font=("Arial", 11, "bold")).grid(row=0, column=1, padx=20)

    # --- Informações adicionais ---
    frame_info = Frame(janela, bg="black")
    frame_info.pack(pady=10)
    
    Label(frame_info, text="💡 Digite o CNPJ para buscar automaticamente a razão social", 
          font=("Arial", 9), bg="black", fg="gray").pack()

# --- Cadastro de Prestadores de Serviços ---
def abrir_prestadores_servicos():
    janela = Toplevel(root)
    janela.title("Cadastro de Prestadores de Serviços")
    centralizar_janela(janela, 600, 300)
    janela.configure(bg="black")

    Label(janela, text="Cadastro de Prestadores de Serviços", font=("Arial", 14), bg="black", fg="white").pack(pady=10)

    frame_campos = Frame(janela, bg="black")
    frame_campos.pack(pady=10)

    Label(frame_campos, text="Razão Social:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="e")
    entry_razao = Entry(frame_campos, width=40, bg="gray20", fg="white", insertbackground="white")
    entry_razao.grid(row=0, column=1, padx=10, pady=5)

    Label(frame_campos, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_cnpj = Entry(frame_campos, width=40, bg="gray20", fg="white", insertbackground="white")
    entry_cnpj.grid(row=1, column=1, padx=10, pady=5)

    def cadastrar_prestador():
        razao = entry_razao.get()
        cnpj = entry_cnpj.get()
        if not razao or not cnpj:
            messagebox.showwarning("Aviso", "Preencha todos os campos.")
            return
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            sql = "INSERT INTO prestadores (razao_social, cnpj) VALUES (%s, %s)"
            cursor.execute(sql, (razao, cnpj))
            conn.commit()
            messagebox.showinfo("Sucesso", f"Prestador '{razao}' cadastrado com sucesso!")
            entry_razao.delete(0, END)
            entry_cnpj.delete(0, END)
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro: {err}")
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conn' in locals(): conn.close()

    def limpar_campos():
        entry_razao.delete(0, END)
        entry_cnpj.delete(0, END)

    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=10)
    Button(frame_botoes, text="Cadastrar", width=15, command=cadastrar_prestador, bg="gray30", fg="white").grid(row=0, column=0, padx=10)
    Button(frame_botoes, text="Limpar", width=15, command=limpar_campos, bg="gray30", fg="white").grid(row=0, column=1, padx=10)

# --- Consulta de Prestadores por CNPJ ---
def abrir_consulta_prestadores():
    janela = Toplevel(root)
    janela.title("Consulta de Prestadores")
    centralizar_janela(janela, 500, 250)
    janela.configure(bg="black")

    Label(janela, text="Consulta de Prestadores por CNPJ", font=("Arial", 14), bg="black", fg="white").pack(pady=10)

    frame_campos = Frame(janela, bg="black")
    frame_campos.pack(pady=10)

    Label(frame_campos, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="e")
    entry_cnpj = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
    entry_cnpj.grid(row=0, column=1, padx=10, pady=5)

    resultado_label = Label(janela, text="", font=("Arial", 12), bg="black", fg="white", justify="left")
    resultado_label.pack(pady=20)

    def consultar():
        cnpj = entry_cnpj.get()
        if not cnpj:
            messagebox.showwarning("Aviso", "Digite um CNPJ para consultar.")
            return
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            cursor.execute("SELECT razao_social, cnpj FROM prestadores WHERE cnpj = %s", (cnpj,))
            resultado = cursor.fetchone()
            if resultado:
                razao, cnpj_encontrado = resultado
                resultado_label.config(text=f"Razão Social: {razao}\nCNPJ: {cnpj_encontrado}")
            else:
                resultado_label.config(text="Nenhuma empresa encontrada com esse CNPJ.")
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro: {err}")
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conn' in locals(): conn.close()

    Button(janela, text="Consultar", width=15, command=consultar, bg="gray30", fg="white").pack(pady=10)

# --- Lista de Prestadores ---
def abrir_lista_prestadores():
    janela = Toplevel(root)
    janela.title("Lista de Prestadores")
    centralizar_janela(janela, 700, 400)
    janela.configure(bg="black")

    Label(janela, text="Lista de Prestadores de Serviços", font=("Arial", 14), bg="black", fg="white").pack(pady=10)

    colunas = ("ID", "Razão Social", "CNPJ")
    tree = ttk.Treeview(janela, columns=colunas, show="headings", height=12)
    for col in colunas:
        tree.heading(col, text=col)
        tree.column(col, width=200)
    tree.pack(pady=10)

    def carregar_dados():
        for i in tree.get_children():
            tree.delete(i)
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            cursor.execute("SELECT id, razao_social, cnpj FROM prestadores")
            for row in cursor.fetchall():
                tree.insert("", "end", values=row)
        except mysql.connector.Error as err:
            messagebox.showerror("Erro de Banco", f"Erro: {err}")
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conn' in locals(): conn.close()

    carregar_dados()

    def excluir_prestador():
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Selecione um prestador para excluir.")
            return
        item = tree.item(selected)
        prestador_id = item['values'][0]
        if messagebox.askyesno("Confirmação", "Deseja realmente excluir este prestador?"):
            try:
                conn = mysql.connector.connect(**config)
                cursor = conn.cursor()
                cursor.execute("DELETE FROM prestadores WHERE id = %s", (prestador_id,))
                conn.commit()
                messagebox.showinfo("Sucesso", "Prestador excluído com sucesso!")
                carregar_dados()
            except mysql.connector.Error as err:
                messagebox.showerror("Erro de Banco", f"Erro: {err}")
            finally:
                if 'cursor' in locals(): cursor.close()
                if 'conn' in locals(): conn.close()

    def editar_prestador():
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Selecione um prestador para editar.")
            return
        item = tree.item(selected)
        prestador_id, razao, cnpj = item['values']

        edit_win = Toplevel(janela)
        edit_win.title("Editar Prestador")
        centralizar_janela(edit_win, 500, 250)
        edit_win.configure(bg="black")

        Label(edit_win, text="Editar Prestador", font=("Arial", 14), bg="black", fg="white").pack(pady=10)
        frame_campos = Frame(edit_win, bg="black")
        frame_campos.pack(pady=10)

        Label(frame_campos, text="Razão Social:", font=("Arial", 12), bg="black", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="e")
        entry_razao = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
        entry_razao.grid(row=0, column=1, padx=10, pady=5)
        entry_razao.insert(0, razao)

        Label(frame_campos, text="CNPJ:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=5, sticky="e")
        entry_cnpj = Entry(frame_campos, width=30, bg="gray20", fg="white", insertbackground="white")
        entry_cnpj.grid(row=1, column=1, padx=10, pady=5)
        entry_cnpj.insert(0, cnpj)

        def salvar_edicao():
            nova_razao = entry_razao.get()
            novo_cnpj = entry_cnpj.get()
            if not nova_razao or not novo_cnpj:
                messagebox.showwarning("Aviso", "Preencha todos os campos.")
                return
            try:
                conn = mysql.connector.connect(**config)
                cursor = conn.cursor()
                cursor.execute("UPDATE prestadores SET razao_social=%s, cnpj=%s WHERE id=%s",
                               (nova_razao, novo_cnpj, prestador_id))
                conn.commit()
                messagebox.showinfo("Sucesso", "Prestador atualizado com sucesso!")
                edit_win.destroy()
                carregar_dados()
            except mysql.connector.Error as err:
                messagebox.showerror("Erro de Banco", f"Erro: {err}")
            finally:
                if 'cursor' in locals(): cursor.close()
                if 'conn' in locals(): conn.close()

        Button(edit_win, text="Salvar", width=15, command=salvar_edicao, bg="gray30", fg="white").pack(pady=10)

    frame_botoes = Frame(janela, bg="black")
    frame_botoes.pack(pady=10)
    Button(frame_botoes, text="Editar", width=15, command=editar_prestador, bg="gray30", fg="white").grid(row=0, column=0, padx=10)
    Button(frame_botoes, text="Excluir", width=15, command=excluir_prestador, bg="gray30", fg="white").grid(row=0, column=1, padx=10)

# --- Painel principal pós-login ---
def abrir_painel_principal():
    centralizar_janela(root, 700, 500)
    root.configure(bg="black")
    painel_frame.configure(bg="black")
    painel_frame.pack(expand=True)

# --- Interface gráfica ---
root = Tk()
root.title("Gerenciador Financeiro ContAÍ")
centralizar_janela(root, 600, 500)
root.resizable(False, False)
root.configure(bg="black")

# --- Frame de login ---
login_frame = Frame(root, bg="black")
login_frame.pack(expand=True)

# Adicionar imagem na tela de login
try:
    img = Image.open(r"images\\logo.png")
    img = img.resize((150, 150))
    photo = ImageTk.PhotoImage(img)
    label_img = Label(login_frame, image=photo, bg="black")
    label_img.image = photo
    label_img.grid(row=0, column=0, columnspan=2, pady=10)
except Exception as e:
    print(f"Erro ao carregar a imagem: {e}")

# Campos de login
Label(login_frame, text="Nome de Usuário:", font=("Arial", 12), bg="black", fg="white").grid(row=1, column=0, padx=10, pady=10, sticky="e")
entry_username = Entry(login_frame, width=30, bg="gray20", fg="white", insertbackground="white")
entry_username.grid(row=1, column=1, padx=10, pady=10)

Label(login_frame, text="Senha:", font=("Arial", 12), bg="black", fg="white").grid(row=2, column=0, padx=10, pady=10, sticky="e")
entry_senha = Entry(login_frame, show="*", width=30, bg="gray20", fg="white", insertbackground="white")
entry_senha.grid(row=2, column=1, padx=10, pady=10)

Button(login_frame, text="Login", width=15, command=verificar_login, bg="gray30", fg="white").grid(row=3, column=0, pady=20)
Button(login_frame, text="Registrar", width=15, command=registrar_usuario, bg="gray30", fg="white").grid(row=3, column=1, pady=20)

# --- Frame do painel principal ---
painel_frame = Frame(root, bg="black")

# Adicionar imagem no painel principal
try:
    img_panel = Image.open(r"images\\logo.png")
    img_panel = img_panel.resize((120, 120))
    photo_panel = ImageTk.PhotoImage(img_panel)
    label_img_panel = Label(painel_frame, image=photo_panel, bg="black")
    label_img_panel.image = photo_panel
    label_img_panel.pack(pady=10)
except Exception as e:
    print(f"Erro ao carregar a imagem no painel: {e}")

Label(painel_frame, text="Painel Principal", font=("Arial", 16), bg="black", fg="white").pack(pady=10)

# --- Área rolável para os botões ---
canvas = Canvas(painel_frame, bg="black", highlightthickness=0)
scrollbar = Scrollbar(painel_frame, orient="vertical", command=canvas.yview)
scrollable_frame = Frame(canvas, bg="black")
scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)
canvas_frame = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)
canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# --- Botões do painel principal ---
botoes_info = [
    ("Contas Vencidas", abrir_contas_vencidas),
    ("Contas a Pagar/Receber", abrir_contas_pagar_receber),
    ("Prestadores de Serviços", abrir_prestadores_servicos),
    ("Consulta de Prestadores", abrir_consulta_prestadores),
    ("Lista de Prestadores", abrir_lista_prestadores),
    ("Escrituração de Notas Fiscais", abrir_escrituracao_notas),
    ("Pesquisa de Notas Fiscais", abrir_pesquisa_notas),
    ("Agenda de Prazos", abrir_agenda_prazos),
]

for texto, comando in botoes_info:
    Button(scrollable_frame, text=texto, width=35, command=comando, bg="gray30", fg="white").pack(pady=5)

def _on_mousewheel(event):
    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
canvas.bind_all("<MouseWheel>", _on_mousewheel)

root.mainloop()